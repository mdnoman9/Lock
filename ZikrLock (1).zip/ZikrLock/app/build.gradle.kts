plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.zikrlock"
    compileSdk = 34
    defaultConfig { applicationId = "com.example.zikrlock"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0"
        buildConfigField("String", "AI_KEY", "\"${System.getenv("AI_KEY") ?: "oc_sk_4d4ef0c312fa_L7rQdC7aF_wjPklnnmL6Ao8l3DBfh_wV"}\"")
        buildConfigField("String", "AI_MODEL", "\"deepseek-v4.1-flash-free\"")
    }
    signingConfigs { create("fixed") { storeFile = file("zikr.keystore"); storePassword = "zikrlock"; keyAlias = "zikr"; keyPassword = "zikrlock" } }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("fixed") } }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
}
