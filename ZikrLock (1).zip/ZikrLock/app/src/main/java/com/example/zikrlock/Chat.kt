package com.example.zikrlock
import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ChatScreen(onBack: () -> Unit) {
    val act = LocalContext.current as? Activity
    val msgs = remember { mutableStateListOf<Pair<String, String>>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun send() {
        val q = input.trim()
        if (q.isEmpty() || busy) return
        input = ""; msgs.add("user" to q); busy = true
        val hist = msgs.toList()
        Thread {
            val r = Planner.chat(hist) ?: "দুঃখিত, এখন এআই-এর সাথে যোগাযোগ করা যাচ্ছে না। ইন্টারনেট পরীক্ষা করে আবার চেষ্টা করুন।"
            act?.runOnUiThread { msgs.add("assistant" to r); busy = false }
        }.start()
    }
    Column(Modifier.fillMaxSize().imePadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("←", color = Color.White, fontSize = 26.sp, modifier = Modifier.clickable { onBack() }.padding(end = 12.dp))
            Text("এআই চ্যাট 🤖", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.weight(1f).padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (msgs.isEmpty()) item { Text("দোয়া, জিকির বা হাদিস নিয়ে যেকোনো প্রশ্ন করুন। এআই ভুল করতে পারে, গুরুত্বপূর্ণ বিষয় আলেমের কাছে যাচাই করুন।", color = Color.Gray, fontSize = 14.sp) }
            items(msgs) { (role, t) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (role == "user") Arrangement.End else Arrangement.Start) {
                    Text(t, color = Color.White, modifier = Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(16.dp)).background(if (role == "user") Green.copy(alpha = .4f) else CardC).padding(12.dp))
                }
            }
            if (busy) item { Text("⏳ এআই ভাবছে...", color = Color.Gray) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("প্রশ্ন লিখুন") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, shape = RoundedCornerShape(14.dp)) { Text("➤") }
        }
    }
}
