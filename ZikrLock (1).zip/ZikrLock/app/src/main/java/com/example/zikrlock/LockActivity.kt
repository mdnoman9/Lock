package com.example.zikrlock
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class LockActivity : ComponentActivity() {
    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
    override fun onStop() { super.onStop(); if (!isFinishing) finish() }
    override fun onDestroy() { LockService.lockUp = false; super.onDestroy() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge(SystemBarStyle.dark(AColor.TRANSPARENT), SystemBarStyle.dark(AColor.TRANSPARENT))
        LockService.lockUp = true
        val pkg = Store.pendPkg(this)
        val gate = Store.pendKind(this) == "gate"
        val gid = Store.pendGid(this)
        val isAi = gid == "AI" || gid == "LOCAL"
        val g = if (isAi) null else Store.groups(this).firstOrNull { it.id == gid }
        if (!isAi && g == null) { finish(); return }
        val textS = mutableStateOf<String?>(null)
        val noteS = mutableStateOf("")
        val targetS = mutableIntStateOf(1)
        var chosen = ""
        if (isAi) {
            targetS.intValue = Store.aiCount(this).coerceAtLeast(1)
            Thread {
                val r = if (gid == "AI") Planner.online(this) else Planner.local(this)
                runOnUiThread { chosen = r.dua.id; noteS.value = r.dua.note + (if (r.tip.isNotBlank()) "\n💡 " + r.tip else ""); textS.value = r.dua.text }
            }.start()
        } else {
            val st = g!!.steps[(if (gate) 0 else Store.idx(this, g)).coerceIn(0, g.steps.lastIndex)]
            targetS.intValue = st.count.coerceAtLeast(1); textS.value = st.text
        }
        fun done() {
            val n = targetS.intValue
            Store.addStats(this, n)
            if (isAi) { Store.addAi(this, chosen, n); if (chosen == "free") Store.addRecent(this, textS.value ?: ""); if (gate) Store.setGate(this, pkg) else Store.setUsed(this, gid, 0) }
            else if (gate) Store.setGate(this, pkg) else Store.advance(this, g!!)
            finish()
        }
        setContent {
            var count by remember { mutableIntStateOf(0) }
            val target = targetS.intValue
            BackHandler { goHome() }
            Column(Modifier.fillMaxSize().background(BgBrush).systemBarsPadding().padding(24.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
                Box(Modifier.size(84.dp).clip(CircleShape).background(Green.copy(alpha = .2f)), contentAlignment = Alignment.Center) { Text("🔒", fontSize = 38.sp) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (gate) "অ্যাপ লক করা আছে" else "সময় হয়েছে ⏰", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(if (gate) "অ্যাপ খোলার আগে এই জিকির করুন" else "ব্যবহারের সময় শেষ, জিকির করে চালিয়ে যান", color = Color.LightGray, fontSize = 14.sp, textAlign = TextAlign.Center)
                }
                val t = textS.value
                if (t == null) {
                    Spacer(Modifier.height(30.dp)); CircularProgressIndicator(color = Green)
                    Text("🤖 আপনার জন্য জিকির বাছা হচ্ছে...", color = Color.LightGray)
                    TextButton(onClick = { goHome() }) { Text("ফিরে যান", color = Color.LightGray) }
                } else {
                    GCard {
                        Text(t, color = Gold, fontSize = 26.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        if (noteS.value.isNotBlank()) Text(noteS.value, color = Color.LightGray, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.size(250.dp).clip(CircleShape).clickable { count++; if (count >= target) done() }, contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val w = 18f; val sz = Size(size.width - w, size.height - w)
                            drawArc(Green.copy(alpha = .18f), 0f, 360f, false, Offset(w / 2, w / 2), sz, style = Stroke(w))
                            drawArc(Green, -90f, 360f * count / target, false, Offset(w / 2, w / 2), sz, style = Stroke(w, cap = StrokeCap.Round))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$count", color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Bold)
                            Text("/ $target  •  ট্যাপ করুন", color = Color.LightGray, fontSize = 14.sp)
                        }
                    }
                    TextButton(onClick = { goHome() }) { Text("ফিরে যান", color = Color.LightGray) }
                }
            }
        }
    }
}
