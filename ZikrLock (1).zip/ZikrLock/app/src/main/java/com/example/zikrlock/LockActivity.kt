package com.example.zikrlock
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class LockActivity : ComponentActivity() {
    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge(SystemBarStyle.dark(AColor.TRANSPARENT), SystemBarStyle.dark(AColor.TRANSPARENT))
        val target = Store.target(this)
        setContent {
            var count by remember { mutableIntStateOf(0) }
            BackHandler { goHome() }
            Column(Modifier.fillMaxSize().background(BgBrush).systemBarsPadding().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
                Box(Modifier.size(84.dp).clip(CircleShape).background(Green.copy(alpha = .2f)), contentAlignment = Alignment.Center) { Text("🔒", fontSize = 38.sp) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("অ্যাপ লক করা আছে", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("ভালো আমল দিয়ে সোশ্যাল মিডিয়া আনলক করুন", color = Color.LightGray, fontSize = 14.sp, textAlign = TextAlign.Center)
                }
                GCard { Text(Store.dhikr(this@LockActivity), color = Gold, fontSize = 28.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth()) }
                Box(Modifier.size(250.dp).clip(CircleShape).clickable {
                    count++
                    if (count >= target) { Store.complete(this@LockActivity); finish() }
                }, contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = 18f; val sz = Size(size.width - w, size.height - w)
                        drawArc(Green.copy(alpha = .18f), 0f, 360f, false, Offset(w / 2, w / 2), sz, style = Stroke(w))
                        drawArc(Green, -90f, 360f * count / target, false, Offset(w / 2, w / 2), sz, style = Stroke(w, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$count", color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Bold)
                        Text("/ $target  •  ট্যাপ করুন", color = Color.LightGray, fontSize = 14.sp)
                    }
                }
                TextButton(onClick = { goHome() }) { Text("ফিরে যান", color = Color.LightGray) }
            }
        }
    }
}
