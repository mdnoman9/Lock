package com.example.zikrlock
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); tick++ }
    private fun serviceOn() = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge(SystemBarStyle.dark(AColor.TRANSPARENT), SystemBarStyle.dark(AColor.TRANSPARENT))
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinct().sortedBy { it.second }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Green)) {
                val on = remember(tick) { serviceOn() }
                App(tick, on, apps) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            }
        }
    }

    @Composable
    fun App(tick: Int, on: Boolean, apps: List<Pair<String, String>>, enable: () -> Unit) {
        var tab by remember { mutableIntStateOf(0) }
        var dhikr by remember { mutableStateOf(Store.dhikr(this)) }
        var target by remember { mutableIntStateOf(Store.target(this)) }
        var mins by remember { mutableIntStateOf(Store.minutes(this)) }
        var locked by remember { mutableStateOf(Store.locked(this)) }
        fun save() = Store.save(this, dhikr, target, mins, locked)
        Column(Modifier.fillMaxSize().background(BgBrush)) {
            Box(Modifier.weight(1f).statusBarsPadding()) {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    when (tab) {
                        0 -> {
                            item {
                                Text("আসসালামু আলাইকুম 🌙", color = Gold, fontSize = 15.sp)
                                Text("ফোনের আসক্তি ভাঙুন,\nজিকিরে মন দিন", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            }
                            item {
                                GCard {
                                    Text(if (on) "🛡️ লক সক্রিয় আছে" else "⚠️ লক বন্ধ আছে", color = if (on) Green else Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("জিকির করে সোশ্যাল মিডিয়া আনলক করুন", color = Color.LightGray, fontSize = 14.sp)
                                    if (!on) { Spacer(Modifier.height(10.dp)); Button(onClick = enable, shape = RoundedCornerShape(14.dp)) { Text("লক চালু করুন (Accessibility)") } }
                                }
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Stat("📿", "আজকের জিকির", Store.dhikrToday(this@MainActivity).toString())
                                    Stat("⏱️", "আনলক মিনিট", Store.minutesToday(this@MainActivity).toString())
                                }
                            }
                            item {
                                GCard {
                                    Text("দৈনিক জিকির অগ্রগতি", color = Color.White, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(12.dp))
                                    Chart(Store.last7(this@MainActivity))
                                    Text("শেষ ৭ দিন", color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                        }
                        1 -> {
                            item { Text("জিকির সেটআপ", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
                            item {
                                GCard {
                                    Text("কী পড়বেন (নিজে লিখুন)", color = Color.LightGray, fontSize = 13.sp)
                                    OutlinedTextField(dhikr, { dhikr = it; save() }, modifier = Modifier.fillMaxWidth(), textStyle = LocalTextStyle.current.copy(fontSize = 20.sp, color = Gold))
                                    Spacer(Modifier.height(10.dp))
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("সুবহানাল্লাহ", "আলহামদুলিল্লাহ", "আল্লাহু আকবার", "আস্তাগফিরুল্লাহ", "লা ইলাহা ইল্লাল্লাহ").forEach {
                                            Text(it, color = Color.White, modifier = Modifier.clip(RoundedCornerShape(50)).background(Green.copy(alpha = .25f)).clickable { dhikr = it; save() }.padding(horizontal = 14.dp, vertical = 8.dp))
                                        }
                                    }
                                }
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Stepper("কতবার পড়বেন", target, 10) { target = it.coerceAtLeast(1); save() }
                                    Stepper("আনলক মিনিট", mins, 1) { mins = it.coerceAtLeast(1); save() }
                                }
                            }
                        }
                        else -> {
                            item { Text("লক করার অ্যাপ", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
                            items(apps) { (pkg, name) ->
                                GCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(name, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                        Switch(pkg in locked, { locked = if (it) locked + pkg else locked - pkg; save() })
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF071A12)).navigationBarsPadding().padding(8.dp)) {
                listOf("🏠" to "হোম", "📿" to "জিকির", "📱" to "অ্যাপ").forEachIndexed { i, (e, l) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { tab = i }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(e, fontSize = 20.sp); Text(l, color = if (tab == i) Green else Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RowScope.Stat(emoji: String, label: String, value: String) = GCard(Modifier.weight(1f)) {
    Text(emoji, fontSize = 22.sp)
    Text(value, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
    Text(label, color = Color.Gray, fontSize = 13.sp)
}

@Composable
fun RowScope.Stepper(label: String, value: Int, step: Int, onChange: (Int) -> Unit) = GCard(Modifier.weight(1f)) {
    Text(label, color = Color.LightGray, fontSize = 13.sp)
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text("−", color = Color.White, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).background(Green.copy(alpha = .25f)).clickable { onChange(value - step) }.padding(horizontal = 14.dp))
        Text("$value", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("+", color = Color.White, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).background(Green.copy(alpha = .25f)).clickable { onChange(value + step) }.padding(horizontal = 14.dp))
    }
}

@Composable
fun Chart(d: List<Int>) {
    val mx = (d.maxOrNull() ?: 1).coerceAtLeast(1)
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val pts = d.mapIndexed { i, v -> Offset(size.width * i / 6f, size.height * (1 - v / mx.toFloat() * .85f) - 6f) }
        val fill = Path().apply { moveTo(0f, size.height); pts.forEach { lineTo(it.x, it.y) }; lineTo(size.width, size.height); close() }
        drawPath(fill, Brush.verticalGradient(listOf(Green.copy(alpha = .35f), Color.Transparent)))
        val line = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
        drawPath(line, Green, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f, cap = StrokeCap.Round))
        pts.forEach { drawCircle(Gold, 7f, it) }
    }
}
