package com.example.zikrlock
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); tick++ }
    private fun serviceOn() = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge(SystemBarStyle.dark(AColor.TRANSPARENT), SystemBarStyle.dark(AColor.TRANSPARENT))
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinct().sortedBy { it.second }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Green)) {
                val on = remember(tick) { serviceOn() }
                App(tick, on, apps) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            }
        }
    }

    fun icon(pkg: String): ImageBitmap? = try { packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() } catch (e: Exception) { null }

    @Composable
    fun AppRow(l: List<String>, names: Map<String, String>) {
        if (l.isEmpty()) { Text("কোনো অ্যাপ বাছা হয়নি", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp)); return }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            l.forEach { pkg ->
                val ic = remember(pkg) { icon(pkg) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (ic != null) Image(ic, null, Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)))
                    Text((names[pkg] ?: pkg).take(9), color = Color.LightGray, fontSize = 10.sp)
                }
            }
        }
    }

    @Composable
    fun App(tick: Int, on: Boolean, apps: List<Pair<String, String>>, enable: () -> Unit) {
        var tab by remember { mutableIntStateOf(0) }
        var pick by remember { mutableIntStateOf(-1) }
        var chat by remember { mutableStateOf(false) }
        var groups by remember { mutableStateOf(Store.groups(this)) }
        fun updG(l: List<Group>) { groups = l; Store.saveGroups(this, l) }
        fun chG(i: Int, f: (Group) -> Group) = updG(groups.mapIndexed { j, x -> if (j == i) f(x) else x })
        val kb = KeyboardOptions(keyboardType = KeyboardType.Number)
        val names = apps.toMap()
        var aiOn by remember { mutableStateOf(Store.aiOn(this)) }
        var aiApps by remember { mutableStateOf(Store.aiApps(this)) }
        var aiDelay by remember { mutableIntStateOf(Store.aiDelay(this)) }
        var aiCount by remember { mutableIntStateOf(Store.aiCount(this)) }
        fun saveAi() = Store.saveAi(this, aiOn, aiApps, aiDelay, aiCount)

        Column(Modifier.fillMaxSize().background(BgBrush)) {
            Box(Modifier.weight(1f).statusBarsPadding()) {
                if (tab == 1 && chat) ChatScreen { chat = false } else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (tab == 0) {
                        item {
                            Text("আসসালামু আলাইকুম 🌙", color = Gold, fontSize = 15.sp)
                            Text("ফোনের আসক্তি ভাঙুন,\nজিকিরে মন দিন", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        }
                        item {
                            Tile(HeroBrush, Modifier.fillMaxWidth()) {
                                Text(if (on) "🛡️ লক সক্রিয় আছে" else "⚠️ লক বন্ধ আছে", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text(if (Net.online(this@MainActivity) && aiOn) "🌐 অনলাইন: এআই জিকির বাছছে" else "📴 অফলাইন/এআই বন্ধ: ম্যানুয়াল সেটিং চলছে", color = Gold, fontSize = 14.sp)
                                Text("প্রতিবার অ্যাপ খোলার আগে জিকির, আর ব্যবহারের সময় পূর্ণ হলে আবার জিকির।", color = Color(0xFFE6FFF2), fontSize = 14.sp)
                                if (!on) { Spacer(Modifier.height(10.dp)); Button(onClick = enable, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF0B3D2A)), shape = RoundedCornerShape(14.dp)) { Text("লক চালু করুন (Accessibility)") } }
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Tile(GoldBrush, Modifier.weight(1f)) { Text("📿", fontSize = 22.sp); Text(Store.dhikrToday(this@MainActivity).toString(), color = Color(0xFF3B2A00), fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("আজকের জিকির", color = Color(0xFF5C4300), fontSize = 13.sp) }
                                Tile(TealBrush, Modifier.weight(1f)) { Text("✅", fontSize = 22.sp); Text(Store.doneToday(this@MainActivity).toString(), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("সম্পন্ন লক", color = Color(0xFFD9F4FF), fontSize = 13.sp) }
                            }
                        }
                        item {
                            GCard {
                                Text("দৈনিক জিকির অগ্রগতি", color = Color.White, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                Chart(Store.last7(this@MainActivity))
                                Text("শেষ ৭ দিন", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    } else if (tab == 1) {
                        item {
                            Text("এআই মোড 🤖", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            Text("এআই হাদিস-ভিত্তিক জিকিরের তালিকা থেকে আজকের অগ্রগতি দেখে প্রতিবার একটা জিকির বাছবে। ইন্টারনেট না থাকলে ম্যানুয়াল সেটিং চলবে।", color = Color.LightGray, fontSize = 13.sp)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { chat = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("💬 এআই-এর সাথে চ্যাট করুন") }
                        }
                        item {
                            GCard {
                                Row(verticalAlignment = Alignment.CenterVertically) { Text("এআই ব্যবহার করুন", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f)); Switch(aiOn, { aiOn = it; saveAi() }) }
                                Text(if (Net.online(this@MainActivity)) "🌐 এখন অনলাইন" else "📴 এখন অফলাইন", color = Green, modifier = Modifier.padding(vertical = 6.dp))
                                OutlinedButton(onClick = { pick = -2 }, shape = RoundedCornerShape(12.dp)) { Text("📱 অ্যাপ বাছুন (${aiApps.size}টি)", color = Green) }
                                AppRow(aiApps.toList(), names)
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedTextField(aiDelay.toString(), { aiDelay = it.filter(Char::isDigit).take(4).toIntOrNull() ?: 0; saveAi() }, label = { Text("কত মিনিট চালানোর পর") }, keyboardOptions = kb, modifier = Modifier.weight(1f))
                                    OutlinedTextField(aiCount.toString(), { aiCount = it.filter(Char::isDigit).take(4).toIntOrNull() ?: 0; saveAi() }, label = { Text("প্রতিবার কতবার") }, keyboardOptions = kb, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                        item {
                            GCard {
                                Text("ফিক্সড দৈনিক লক্ষ্য (এআই এগুলোর বাইরেও নতুন দোয়া দেয়)", color = Color.White, fontWeight = FontWeight.Bold)
                                CATALOG.forEach { d ->
                                    val done = Store.aiDone(this@MainActivity, d.id)
                                    Text("${d.text.take(28)}   $done/${d.target}", color = Gold, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                                    LinearProgressIndicator(progress = { (done / d.target.toFloat()).coerceIn(0f, 1f) }, color = Green, trackColor = Color(0x331FA463), modifier = Modifier.fillMaxWidth())
                                }
                            }
                        }
                    } else {
                        item {
                            Text("ম্যানুয়াল সেটআপ (অফলাইনে চলে)", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            Text("প্রতিটা গ্রুপে অ্যাপ বাছুন, তারপর সেই অ্যাপের জন্য জিকিরগুলো সাজান।", color = Color.LightGray, fontSize = 13.sp)
                        }
                        itemsIndexed(groups) { gi, g ->
                            GCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("গ্রুপ ${gi + 1}", color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    if (groups.size > 1) Text("🗑️", fontSize = 20.sp, modifier = Modifier.clickable { updG(groups.filterIndexed { j, _ -> j != gi }) })
                                }
                                AppRow(g.apps, names)
                                OutlinedButton(onClick = { pick = gi }, shape = RoundedCornerShape(12.dp)) { Text("📱 অ্যাপ বাছুন", color = Green) }
                                g.steps.forEachIndexed { si, st ->
                                    fun chs(f: (Step) -> Step) = chG(gi) { it.copy(steps = it.steps.mapIndexed { k, x -> if (k == si) f(x) else x }) }
                                    Column(Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x221FA463)).padding(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(if (si == 0) "জিকির ১ (প্রতিবার অ্যাপ খুললে)" else "জিকির ${si + 1}", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                            if (g.steps.size > 1) Text("🗑️", fontSize = 18.sp, modifier = Modifier.clickable { chG(gi) { it.copy(steps = it.steps.filterIndexed { k, _ -> k != si }) } })
                                        }
                                        OutlinedTextField(st.text, { chs { x -> x.copy(text = it) } }, label = { Text("কী পড়বেন") }, modifier = Modifier.fillMaxWidth(), textStyle = LocalTextStyle.current.copy(fontSize = 20.sp, color = Gold))
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            OutlinedTextField(st.count.toString(), { chs { x -> x.copy(count = it.filter(Char::isDigit).take(4).toIntOrNull() ?: 0) } }, label = { Text("কতবার") }, keyboardOptions = kb, modifier = Modifier.weight(1f))
                                            OutlinedTextField(st.delay.toString(), { chs { x -> x.copy(delay = it.filter(Char::isDigit).take(4).toIntOrNull() ?: 0) } }, label = { Text("কত মিনিট চালানোর পর") }, keyboardOptions = kb, modifier = Modifier.weight(1f))
                                        }
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = { chG(gi) { it.copy(steps = it.steps + Step("", 33, 5)) } }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("➕ নতুন জিকির যোগ করুন") }
                            }
                        }
                        item { Button(onClick = { updG(groups + Store.newGroup()) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF3B2A00))) { Text("➕ আলাদা অ্যাপের জন্য যোগ করুন") } }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF071A12)).navigationBarsPadding().padding(8.dp)) {
                listOf("🏠" to "হোম", "🤖" to "এআই", "🔒" to "ম্যানুয়াল").forEachIndexed { i, (e, l) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (tab == i) Green.copy(alpha = .2f) else Color.Transparent).clickable { tab = i }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(e, fontSize = 20.sp); Text(l, color = if (tab == i) Green else Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
        if (pick in groups.indices || pick == -2) AlertDialog(
            onDismissRequest = { pick = -1 }, containerColor = CardC,
            confirmButton = { TextButton(onClick = { pick = -1 }) { Text("ঠিক আছে", color = Green) } },
            title = { Text("অ্যাপ বাছুন", color = Color.White) },
            text = {
                var q by remember { mutableStateOf("") }
                Column {
                    OutlinedTextField(q, { q = it }, placeholder = { Text("🔍 অ্যাপ খুঁজুন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(apps.filter { it.second.contains(q, ignoreCase = true) }) { (pkg, name) ->
                            val sel = pkg in (if (pick == -2) aiApps else groups[pick].apps)
                            val ic = remember(pkg) { icon(pkg) }
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(14.dp))
                                .background(if (sel) Green.copy(alpha = .22f) else Color.Transparent).clickable {
                                    if (pick == -2) { aiApps = if (sel) aiApps - pkg else aiApps + pkg; saveAi() } else updG(groups.mapIndexed { j, g -> if (j == pick) g.copy(apps = if (sel) g.apps - pkg else g.apps + pkg) else g.copy(apps = g.apps - pkg) })
                                }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (ic != null) Image(ic, null, Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))) else Spacer(Modifier.size(40.dp))
                                Spacer(Modifier.width(12.dp)); Text(name, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                Checkbox(sel, null)
                            }
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun Chart(d: List<Int>) {
    val mx = (d.maxOrNull() ?: 1).coerceAtLeast(1)
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val pts = d.mapIndexed { i, v -> Offset(size.width * i / 6f, size.height * (1 - v / mx.toFloat() * .85f) - 6f) }
        val fill = Path().apply { moveTo(0f, size.height); pts.forEach { lineTo(it.x, it.y) }; lineTo(size.width, size.height); close() }
        drawPath(fill, Brush.verticalGradient(listOf(Green.copy(alpha = .35f), Color.Transparent)))
        val line = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
        drawPath(line, Green, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f, cap = StrokeCap.Round))
        pts.forEach { drawCircle(Gold, 7f, it) }
    }
}
