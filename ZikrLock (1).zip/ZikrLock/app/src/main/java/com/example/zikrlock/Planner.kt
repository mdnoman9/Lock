package com.example.zikrlock
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

data class Dua(val id: String, val text: String, val target: Int, val note: String)
data class Pick(val dua: Dua, val tip: String)

val CATALOG = listOf(
    Dua("istighfar", "আস্তাগফিরুল্লাহ", 70, "রাসূলুল্লাহ (সা.) দিনে ৭০ বারের বেশি ইস্তিগফার করতেন (সহীহ বুখারী)"),
    Dua("tasbih_hamd", "সুবহানাল্লাহি ওয়া বিহামদিহি", 100, "দিনে ১০০ বার পড়লে গুনাহ মাফ হয় (সহীহ বুখারী ও মুসলিম)"),
    Dua("tawhid", "লা ইলাহা ইল্লাল্লাহু ওয়াহদাহু লা শারীকা লাহু, লাহুল মুলকু ওয়া লাহুল হামদু ওয়া হুয়া আলা কুল্লি শাইয়িন কাদীর", 100, "দিনে ১০০ বার পড়ার ফযীলত (সহীহ বুখারী ও মুসলিম)"),
    Dua("subhanallah", "সুবহানাল্লাহ", 33, "নামাযের পর ৩৩ বার (সহীহ মুসলিম)"),
    Dua("alhamdulillah", "আলহামদুলিল্লাহ", 33, "নামাযের পর ৩৩ বার (সহীহ মুসলিম)"),
    Dua("allahu_akbar", "আল্লাহু আকবার", 34, "নামাযের পর ৩৪ বার (সহীহ মুসলিম)"),
    Dua("durood", "আল্লাহুম্মা সাল্লি আলা মুহাম্মাদ", 10, "একবার দরুদে আল্লাহ ১০ বার রহমত দেন (সহীহ মুসলিম)"),
    Dua("hawqala", "লা হাওলা ওয়ালা কুওয়াতা ইল্লা বিল্লাহ", 20, "জান্নাতের ধনভাণ্ডারগুলোর একটি (সহীহ বুখারী ও মুসলিম)")
)

object Net {
    fun online(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
    }
}

object Planner {
    private val BASE = "https://opencode.ai/zen/v1/chat/completions"
    private fun models() = listOf(BuildConfig.AI_MODEL, "deepseek-v4.1-flash", "deepseek-v4-flash-free").distinct()

    fun local(c: Context): Pick {
        val last = Store.aiLast(c)
        val sorted = CATALOG.sortedBy { Store.aiDone(c, it.id).toFloat() / it.target }
        return Pick(sorted.firstOrNull { it.id != last } ?: sorted.first(), "")
    }

    private fun post(model: String, msgs: JSONArray, maxTokens: Int, readMs: Int): String? {
        if (BuildConfig.AI_KEY.isBlank()) return null
        val body = JSONObject().put("model", model).put("temperature", 0.7).put("max_tokens", maxTokens).put("messages", msgs)
        val con = URL(BASE).openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.connectTimeout = 4000; con.readTimeout = readMs; con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("Authorization", "Bearer " + BuildConfig.AI_KEY)
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        if (con.responseCode !in 200..299) return null
        val txt = con.inputStream.bufferedReader().readText()
        return JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").takeIf { it.isNotBlank() }
    }
    private fun m(role: String, t: String) = JSONObject().put("role", role).put("content", t)

    fun online(c: Context): Pick {
        val cal = Calendar.getInstance()
        val now = "%02d:%02d".format(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
        val prog = CATALOG.joinToString("\n") { "${it.id}: আজ ${Store.aiDone(c, it.id)}/${it.target} — ${it.text}" }
        val recent = Store.recentFree(c).joinToString("; ").ifBlank { "নেই" }
        val sys = "তুমি একজন জিকির সহায়ক। প্রতিবার ব্যবহারকারীর জন্য একটি বিশুদ্ধ (সহীহ) দোয়া বা জিকির বাছবে। " +
            "দুই রকম বাছতে পারো: (১) ফিক্সড তালিকার কোনো একটি, যদি দিনের সময় অনুযায়ী তার লক্ষ্য পিছিয়ে থাকে; (২) তালিকার বাইরের নতুন একটি সুপরিচিত সহীহ দোয়া বা জিকির (নবী (সা.) থেকে প্রমাণিত), যা আজ আগে দেওয়া হয়নি। " +
            "সাধারণত নতুন দোয়াকে প্রাধান্য দাও, আর ফিক্সড লক্ষ্যগুলো সারাদিনে ছড়িয়ে পূরণ করাও। সময়ের সাথে মানানসই বাছো (সকাল-সন্ধ্যা, ঘুম, ইত্যাদি)। একই জিকির পরপর দিও না। " +
            "নিশ্চিত না হলে ফিক্সড তালিকা থেকে দাও, কিছু বানাবে না। শুধু JSON দাও: " +
            "{\"id\":\"ফিক্সড id অথবা free\",\"text\":\"id=free হলে আরবি বা বাংলা উচ্চারণে দোয়া\",\"meaning\":\"বাংলা অর্থ\",\"source\":\"হাদিস গ্রন্থের নাম\",\"tip\":\"১২ শব্দের মধ্যে উৎসাহ বাক্য\"}"
        val user = "এখন সময়: $now\nশেষবার ফিক্সড: ${Store.aiLast(c)}\nআজ আগে দেওয়া নতুন দোয়া: $recent\nফিক্সড লক্ষ্য ও অগ্রগতি:\n$prog"
        val msgs = JSONArray().put(m("system", sys)).put(m("user", user))
        for (model in models()) {
            try {
                val content = post(model, msgs, 1200, 15000) ?: continue
                val j = Regex("\\{.*\\}", RegexOption.DOT_MATCHES_ALL).find(content)?.value ?: continue
                val o = JSONObject(j)
                val tip = o.optString("tip").take(120)
                CATALOG.firstOrNull { it.id == o.optString("id") }?.let { return Pick(it, tip) }
                val t = o.optString("text").trim()
                if (o.optString("id") == "free" && t.isNotBlank()) {
                    val note = o.optString("meaning").trim() + (o.optString("source").trim().let { if (it.isBlank()) "" else " ($it)" }) + "\n⚠️ এআই-প্রদত্ত, যাচাই করে নিন"
                    return Pick(Dua("free", t.take(300), 0, note.take(400)), tip)
                }
            } catch (e: Exception) { }
        }
        return local(c)
    }

    fun chat(hist: List<Pair<String, String>>): String? {
        val sys = "তুমি একজন ইসলামিক জিকির ও দোয়া বিষয়ক সহায়ক। বাংলায় সংক্ষেপে উত্তর দাও। শুধু সহীহ ও সুপরিচিত দোয়া-জিকির বলো এবং সূত্রের নাম উল্লেখ করো। " +
            "নিশ্চিত না হলে স্পষ্ট বলো এবং আলেমের কাছে যাচাই করতে বলো। ফতোয়া দিও না।"
        val msgs = JSONArray().put(m("system", sys))
        hist.takeLast(12).forEach { msgs.put(m(it.first, it.second)) }
        for (model in models()) { try { post(model, msgs, 1500, 25000)?.let { return it } } catch (e: Exception) { } }
        return null
    }
}
