package com.example.zikrlock
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val BgBrush = Brush.verticalGradient(listOf(Color(0xFF03110A), Color(0xFF0B3D2A)))
val CardC = Color(0xFF0F2A1E)
val Green = Color(0xFF2ECC71)
val Gold = Color(0xFFFFD66B)

@Composable
fun GCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) = Column(
    modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CardC)
        .border(1.dp, Green.copy(alpha = .25f), RoundedCornerShape(22.dp)).padding(16.dp),
    content = content
)
