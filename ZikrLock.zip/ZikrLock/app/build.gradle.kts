plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.zikrlock"
    compileSdk = 34
    defaultConfig { applicationId = "com.example.zikrlock"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    signingConfigs { create("fixed") { storeFile = file("zikr.keystore"); storePassword = "zikrlock"; keyAlias = "zikr"; keyPassword = "zikrlock" } }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("fixed") } }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
}
