package com.example.zikrlock
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class LockActivity : ComponentActivity() {
    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val target = Store.target(this)
        setContent {
            var count by remember { mutableIntStateOf(0) }
            BackHandler { goHome() }
            Column(
                Modifier.fillMaxSize().background(Color(0xFF0B3D2A)).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Text("🔒 অ্যাপ লক করা আছে", color = Color.White, fontSize = 22.sp)
                Spacer(Modifier.height(16.dp))
                Text(Store.dhikr(this@LockActivity), color = Color(0xFFFFD66B), fontSize = 30.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text("$count / $target", color = Color.White, fontSize = 40.sp)
                Spacer(Modifier.height(32.dp))
                Box(
                    Modifier.size(200.dp).clip(CircleShape).background(Color(0xFF1FA463)).clickable {
                        count++
                        if (count >= target) { Store.complete(this@LockActivity); finish() }
                    }, contentAlignment = Alignment.Center
                ) { Text("ট্যাপ করুন", color = Color.White, fontSize = 22.sp) }
                Spacer(Modifier.height(32.dp))
                TextButton(onClick = { goHome() }) { Text("ফিরে যান", color = Color.White) }
            }
        }
    }
}
