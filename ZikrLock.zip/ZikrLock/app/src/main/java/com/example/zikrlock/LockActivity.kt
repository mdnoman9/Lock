package com.example.zikrlock
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class LockActivity : ComponentActivity() {
    private val view = mutableStateOf<Item?>(null)
    private val target = mutableIntStateOf(1)
    private val count = mutableIntStateOf(0)
    private var kind = ""
    private var gid = ""
    private var pkg = ""
    private var group: Group? = null

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
    override fun onStop() { super.onStop(); if (!isFinishing) finish() }
    override fun onDestroy() { LockService.lockUp = false; super.onDestroy() }

    private fun chunkFor(i: Item): Int {
        val ch = if (kind == "rand") Store.gi(this, "rand_chunk", 10) else Store.gi(this, "lib_count", 10)
        val rem = Lib.rem(this, i)
        return (if (rem > 0) minOf(ch, rem) else ch).coerceAtLeast(1)
    }
    private fun load(i: Item, slot: Boolean) {
        view.value = i
        if (slot) { target.intValue = i.goal.coerceAtLeast(1); count.intValue = Store.prog(this, i.id).coerceAtMost(target.intValue) }
        else { target.intValue = chunkFor(i); count.intValue = 0 }
    }
    private fun complete() {
        val v = view.value
        if (kind == "slot") {
            val next = Lib.pending(this, gid).filter { it.id != v?.id }
            if (next.isEmpty()) { Store.addDone(this); finish() } else load(next.first(), true)
        } else if (kind == "rand") { Store.addDone(this); finish() }
        else if (gid == "LIB") {
            Store.addDone(this)
            if (kind == "gate") Store.setGate(this, pkg) else Store.setUsed(this, "LIB", 0)
            finish()
        } else {
            Store.addStats(this, target.intValue)
            if (kind == "gate") Store.setGate(this, pkg) else group?.let { Store.advance(this, it) }
            finish()
        }
    }
    private fun tap() {
        val v = view.value ?: return
        if (v.id.isNotBlank()) Store.addProg(this, v.id, 1)
        count.intValue = count.intValue + 1
        if (count.intValue >= target.intValue) complete()
    }
    private fun nextItem() {
        val all = Lib.pending(this, gid)
        if (all.size < 2) return
        val i = all.indexOfFirst { it.id == view.value?.id }
        load(all[(i + 1) % all.size], true)
    }
    private fun skip() {
        Store.sl(this, "sn", System.currentTimeMillis() + Store.gi(this, "skip_min", 10) * 60000L)
        finish()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge(SystemBarStyle.dark(AColor.TRANSPARENT), SystemBarStyle.dark(AColor.TRANSPARENT))
        LockService.lockUp = true
        kind = Store.pendKind(this); gid = Store.pendGid(this); pkg = Store.pendPkg(this)
        var ok = true
        if (kind == "slot") {
            val i = Lib.pending(this, gid).firstOrNull()
            if (i == null) ok = false else load(i, true)
        } else if (kind == "rand") {
            val i = Lib.randomPick(this, "")
            if (i == null) ok = false else load(i, false)
        } else if (gid == "LIB") {
            val i = Lib.randomPick(this, "") ?: Store.lib(this).filter { it.cat == "D" }.randomOrNull()
                ?: Item("", "", "আস্তাগফিরুল্লাহ", "", "", "", "", "", 0, 10)
            load(i, false)
        } else {
            group = Store.groups(this).firstOrNull { it.id == gid }
            val g = group
            if (g == null) ok = false else {
                val st = g.steps[(if (kind == "gate") 0 else Store.idx(this, g)).coerceIn(0, g.steps.lastIndex)]
                view.value = Item("", "", st.text, "", "", "", "", "", 0, st.count)
                target.intValue = st.count.coerceAtLeast(1)
            }
        }
        if (!ok) { finish(); return }
        val popup = kind == "slot" || kind == "rand"
        setContent {
            val v = view.value
            val skipMin = Store.gi(this, "skip_min", 10)
            BackHandler { if (popup) finish() else goHome() }
            Column(Modifier.fillMaxSize().background(BgBrush).systemBarsPadding().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Green.copy(alpha = .2f)), contentAlignment = Alignment.Center) { Text(if (popup) "📿" else "🔒", fontSize = 22.sp) }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        when {
                            kind == "slot" -> Lib.CATS.firstOrNull { it.first == gid }?.second ?: "জিকির"
                            kind == "rand" -> "📿 এখন একটু জিকির করুন"
                            kind == "gate" -> "অ্যাপ লক করা আছে"
                            else -> "সময় হয়েছে ⏰"
                        }, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold
                    )
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 12.dp)) {
                    if (v != null) GCard {
                        ItemBody(v)
                        if (v.id.isNotBlank()) {
                            val done = run { count.intValue; Store.prog(this@LockActivity, v.id) }
                            Text(Lib.goalLabel(v), color = Gold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                            Text("আজ: $done / ${v.goal}", color = Green, fontSize = 13.sp)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(150.dp).clip(CircleShape).clickable { tap() }, contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val w = 14f; val sz = Size(size.width - w, size.height - w)
                            drawArc(Green.copy(alpha = .18f), 0f, 360f, false, Offset(w / 2, w / 2), sz, style = Stroke(w))
                            drawArc(Green, -90f, 360f * count.intValue / target.intValue, false, Offset(w / 2, w / 2), sz, style = Stroke(w, cap = StrokeCap.Round))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${count.intValue}", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                            Text("/ ${target.intValue} • ট্যাপ", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (kind == "slot") OutlinedButton(onClick = { nextItem() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("পরেরটা ›", color = Green) }
                        if (popup) {
                            OutlinedButton(onClick = { skip() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("⏭ স্কিপ ($skipMin মি.)", color = Gold) }
                            TextButton(onClick = { finish() }, modifier = Modifier.fillMaxWidth()) { Text("বন্ধ করুন", color = Color.LightGray) }
                        } else TextButton(onClick = { goHome() }, modifier = Modifier.fillMaxWidth()) { Text("ফিরে যান", color = Color.LightGray) }
                    }
                }
            }
        }
    }
}
