package com.example.zikrlock
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import java.util.Calendar

class LockService : AccessibilityService() {
    companion object { @Volatile var lockUp = false }
    private val h = Handler(Looper.getMainLooper())
    private var cur: String? = null

    private fun plan(pkg: String): Pair<String, Int>? {
        if (Store.gb(this, "lib_on", true) && pkg in Store.gs(this, "lib_apps")) return "LIB" to Store.gi(this, "lib_delay", 10)
        Store.groupFor(this, pkg)?.let { return it.id to it.steps[Store.idx(this, it)].delay }
        return null
    }

    private fun inCall(): Boolean {
        val m = getSystemService(AudioManager::class.java).mode
        return m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_IN_COMMUNICATION || m == AudioManager.MODE_RINGTONE
    }

    private fun popups(pkg: String?) {
        val c = this
        if (!Store.gb(c, "pop_on", true)) return
        val now = System.currentTimeMillis()
        if (now < Store.gl(c, "sn")) return
        if (Store.gb(c, "call_guard", true) && inCall()) return
        if (pkg != null && pkg in Store.gs(c, "excl")) return
        val cal = Calendar.getInstance()
        val mod = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        for (cat in listOf("M", "E", "N")) {
            if (!Store.gb(c, "slot_$cat", true) || now < Store.gl(c, "sx_$cat") || !Lib.inWindow(c, cat, mod)) continue
            if (Lib.pending(c, cat).isEmpty()) continue
            Store.sl(c, "sx_$cat", now + Store.gi(c, "skip_min", 10) * 60000L)
            show(pkg ?: "", "slot", cat)
            return
        }
        val iv = Store.gi(c, "rand_iv", 15)
        if (iv > 0) {
            val rn = Store.gl(c, "rn")
            if (rn == 0L) { Store.sl(c, "rn", now + iv * 60000L); return }
            if (now >= rn) {
                Store.sl(c, "rn", now + iv * 60000L)
                if (Lib.randomPick(c, "") != null) show(pkg ?: "", "rand", "R")
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val pkg = cur
            if (!lockUp && getSystemService(PowerManager::class.java).isInteractive) {
                val pl = if (pkg != null) plan(pkg) else null
                if (pl != null && pkg != null) {
                    if (Store.gate(this@LockService) != pkg) show(pkg, "gate", pl.first)
                    else {
                        val u = Store.used(this@LockService, pl.first) + 1
                        Store.setUsed(this@LockService, pl.first, u)
                        if (u >= pl.second.coerceAtLeast(1) * 60) show(pkg, "timed", pl.first)
                    }
                } else popups(pkg)
            }
            h.postDelayed(this, 1000)
        }
    }
    override fun onServiceConnected() { h.post(tick) }
    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }

    private fun show(pkg: String, kind: String, gid: String) {
        lockUp = true
        Store.setPending(this, pkg, kind, gid)
        try { startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { lockUp = false }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg.contains("inputmethod") || pkg == "com.android.systemui") return
        if (pkg != cur) {
            cur = pkg; Store.setGate(this, "")
            if (!lockUp) plan(pkg)?.let { show(pkg, "gate", it.first) }
        }
    }
    override fun onInterrupt() {}
}
