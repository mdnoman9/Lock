package com.example.zikrlock
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    companion object { @Volatile var lockUp = false }
    private val h = Handler(Looper.getMainLooper())
    private var cur: String? = null

    private val tick = object : Runnable {
        override fun run() {
            val pkg = cur
            if (pkg != null && !lockUp && getSystemService(PowerManager::class.java).isInteractive) {
                val g = Store.groupFor(this@LockService, pkg)
                if (g != null) {
                    if (Store.gate(this@LockService) != pkg) show(pkg, "gate", g.id)
                    else {
                        val u = Store.used(this@LockService, g) + 1
                        Store.setUsed(this@LockService, g.id, u)
                        if (u >= g.steps[Store.idx(this@LockService, g)].delay.coerceAtLeast(1) * 60) show(pkg, "timed", g.id)
                    }
                }
            }
            h.postDelayed(this, 1000)
        }
    }
    override fun onServiceConnected() { h.post(tick) }
    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }

    private fun show(pkg: String, kind: String, gid: String) {
        lockUp = true
        Store.setPending(this, pkg, kind, gid)
        try { startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { lockUp = false }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg.contains("inputmethod") || pkg == "com.android.systemui") return
        if (pkg != cur) {
            cur = pkg; Store.setGate(this, "")
            val g = Store.groupFor(this, pkg)
            if (g != null && !lockUp) show(pkg, "gate", g.id)
        }
    }
    override fun onInterrupt() {}
}
