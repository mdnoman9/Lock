package com.example.zikrlock
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    companion object { @Volatile var lockUp = false }
    private val h = Handler(Looper.getMainLooper())
    private var cur: String? = null

    private fun plan(pkg: String): Pair<String, Int>? {
        val ai = Store.aiOn(this) && pkg in Store.aiApps(this)
        if (ai && Net.online(this)) return "AI" to Store.aiDelay(this)
        Store.groupFor(this, pkg)?.let { return it.id to it.steps[Store.idx(this, it)].delay }
        if (ai) return "LOCAL" to Store.aiDelay(this)
        return null
    }

    private val tick = object : Runnable {
        override fun run() {
            val pkg = cur
            if (pkg != null && !lockUp && getSystemService(PowerManager::class.java).isInteractive) {
                val pl = plan(pkg)
                if (pl != null) {
                    if (Store.gate(this@LockService) != pkg) show(pkg, "gate", pl.first)
                    else {
                        val u = Store.used(this@LockService, pl.first) + 1
                        Store.setUsed(this@LockService, pl.first, u)
                        if (u >= pl.second.coerceAtLeast(1) * 60) show(pkg, "timed", pl.first)
                    }
                }
            }
            h.postDelayed(this, 1000)
        }
    }
    override fun onServiceConnected() { h.post(tick) }
    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }

    private fun show(pkg: String, kind: String, gid: String) {
        lockUp = true
        Store.setPending(this, pkg, kind, gid)
        try { startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { lockUp = false }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg.contains("inputmethod") || pkg == "com.android.systemui") return
        if (pkg != cur) {
            cur = pkg; Store.setGate(this, "")
            if (!lockUp) plan(pkg)?.let { show(pkg, "gate", it.first) }
        }
    }
    override fun onInterrupt() {}
}
