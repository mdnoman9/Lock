package com.example.zikrlock
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); tick++ }
    private fun serviceOn() = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinct().sortedBy { it.second }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF1FA463))) {
                var dhikr by remember { mutableStateOf(Store.dhikr(this)) }
                var target by remember { mutableStateOf(Store.target(this).toString()) }
                var mins by remember { mutableStateOf(Store.minutes(this).toString()) }
                var locked by remember { mutableStateOf(Store.locked(this)) }
                fun save() = Store.save(this, dhikr, target.toIntOrNull()?.coerceAtLeast(1) ?: 33, mins.toIntOrNull()?.coerceAtLeast(1) ?: 10, locked)
                val t = tick
                LazyColumn(Modifier.fillMaxSize().background(Color(0xFF0A0A0A)).statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text("ZikrLock", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                        Text("আজকের জিকির: ${Store.dhikrToday(this@MainActivity)}   |   আনলক মিনিট: ${Store.minutesToday(this@MainActivity)}", color = Color.LightGray)
                        val d = Store.last7(this@MainActivity); val mx = (d.maxOrNull() ?: 1).coerceAtLeast(1)
                        Row(Modifier.fillMaxWidth().height(80.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
                            d.forEach { Box(Modifier.weight(1f).fillMaxHeight((it.toFloat() / mx).coerceAtLeast(0.04f)).background(Color(0xFF1FA463))) }
                        }
                        Text("শেষ ৭ দিনের জিকির", color = Color.Gray)
                        if (!serviceOn()) Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("লক চালু করতে Accessibility অনুমতি দিন") }
                        else Text("✅ লক সক্রিয়", color = Color(0xFF1FA463))
                        OutlinedTextField(dhikr, { dhikr = it; save() }, label = { Text("জিকির / দোয়া (নিজে লিখুন)") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(target, { target = it.filter(Char::isDigit); save() }, label = { Text("কতবার") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(mins, { mins = it.filter(Char::isDigit); save() }, label = { Text("আনলক মিনিট") }, modifier = Modifier.weight(1f))
                        }
                        Text("যে অ্যাপগুলো লক হবে:", color = Color.White)
                    }
                    items(apps) { (pkg, name) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(pkg in locked, { locked = if (it) locked + pkg else locked - pkg; save() })
                            Text(name, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
