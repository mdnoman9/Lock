package com.example.zikrlock
import android.content.Context
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

class UiS(val ctx: Context, val apps: List<Pair<String, String>>) {
    val names = apps.toMap()
    var tab by mutableIntStateOf(0)
    var pick by mutableIntStateOf(-1)
    var bump by mutableIntStateOf(0)
    var groups by mutableStateOf(Store.groups(ctx))
    var items by mutableStateOf(Store.lib(ctx))
    var cat by mutableStateOf("M")
    var edit by mutableStateOf<Item?>(null)
    var libOn by mutableStateOf(Store.gb(ctx, "lib_on", true))
    var libApps by mutableStateOf(Store.gs(ctx, "lib_apps"))
    var libDelay by mutableIntStateOf(Store.gi(ctx, "lib_delay", 10))
    var libCount by mutableIntStateOf(Store.gi(ctx, "lib_count", 10))
    var excl by mutableStateOf(Store.gs(ctx, "excl"))
    fun updG(l: List<Group>) { groups = l; Store.saveGroups(ctx, l) }
    fun chG(i: Int, f: (Group) -> Group) = updG(groups.mapIndexed { j, x -> if (j == i) f(x) else x })
    fun saveLibCfg() { Store.sb(ctx, "lib_on", libOn); Store.ss(ctx, "lib_apps", libApps); Store.si(ctx, "lib_delay", libDelay); Store.si(ctx, "lib_count", libCount) }
    fun saveItems(l: List<Item>) { items = l; Store.saveLib(ctx, l) }
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); tick++ }
    private val ctx: Context get() = this
    private fun serviceOn() = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
    fun icon(pkg: String): ImageBitmap? = try { packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() } catch (e: Exception) { null }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge(SystemBarStyle.dark(AColor.TRANSPARENT), SystemBarStyle.dark(AColor.TRANSPARENT))
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinct().sortedBy { it.second }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Green)) {
                val on = remember(tick) { serviceOn() }
                App(tick, on, apps) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            }
        }
    }

    @Composable
    fun App(tick: Int, on: Boolean, apps: List<Pair<String, String>>, enable: () -> Unit) {
        val s = remember { UiS(this, apps) }
        LaunchedEffect(tick) { s.bump = s.bump + 1 }
        Column(Modifier.fillMaxSize().background(BgBrush)) {
            Box(Modifier.weight(1f).statusBarsPadding()) {
                LazyColumn(Modifier.fillMaxSize().imePadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    when (s.tab) { 0 -> homeTab(s, on, enable); 1 -> libTab(s); 2 -> lockTab(s); else -> setTab(s, on, enable) }
                }
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF071A12)).navigationBarsPadding().padding(8.dp)) {
                listOf("🏠" to "হোম", "📿" to "জিকির", "🔒" to "অ্যাপ লক", "⚙️" to "সেটিংস").forEachIndexed { i, (e, l) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (s.tab == i) Green.copy(alpha = .2f) else Color.Transparent).clickable { s.tab = i }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(e, fontSize = 20.sp); Text(l, color = if (s.tab == i) Green else Color.Gray, fontSize = 11.sp)
                    }
                }
            }
        }
        PickDialog(s)
        s.edit?.let { e ->
            val del: (() -> Unit)? = if (e.id.isBlank()) null else ({ s.saveItems(s.items.filter { x -> x.id != e.id }); s.edit = null })
            EditDialog(e, onSave = { n ->
                if (e.id.isBlank()) s.saveItems(s.items + n.copy(id = "c_" + System.currentTimeMillis(), custom = true))
                else s.saveItems(s.items.map { x -> if (x.id == e.id) n else x })
                s.cat = n.cat; s.edit = null
            }, onDelete = del, onDismiss = { s.edit = null })
        }
    }

    // ---------- হোম ----------
    private fun LazyListScope.homeTab(s: UiS, on: Boolean, enable: () -> Unit) {
        item {
            Text("আসসালামু আলাইকুম 🌙", color = Gold, fontSize = 15.sp)
            Text("ফোনের আসক্তি ভাঙুন,\nজিকিরে মন দিন", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Tile(HeroBrush, Modifier.fillMaxWidth()) {
                Text(if (on) "🛡️ সক্রিয় আছে" else "⚠️ বন্ধ আছে", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("সকাল-সন্ধ্যা-রাতের জিকির সময়মতো এবং সারাদিনের জিকির মাঝে মাঝে পূর্ণ পর্দায় আসবে; লক করা অ্যাপ খোলার আগেও জিকির করতে হবে।", color = Color(0xFFE6FFF2), fontSize = 14.sp)
                if (!on) { Spacer(Modifier.height(10.dp)); Button(onClick = enable, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF0B3D2A)), shape = RoundedCornerShape(14.dp)) { Text("চালু করুন (Accessibility)") } }
            }
        }
        item {
            GCard {
                Text("আজকের তালিকা", color = Color.White, fontWeight = FontWeight.Bold)
                listOf("M" to "🌅 সকালের জিকির", "E" to "🌇 সন্ধ্যার জিকির", "N" to "🌙 রাতের আমল").forEach { (k, l) ->
                    val n = run { s.bump; Lib.pending(ctx, k).size }
                    Text("$l: " + if (n == 0) "✅ সম্পন্ন" else "⏳ বাকি $n টি", color = if (n == 0) Green else Gold, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        item {
            val taps = run { s.bump; Store.dhikrToday(ctx) }
            val done = run { s.bump; Store.doneToday(ctx) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(GoldBrush, Modifier.weight(1f)) { Text("📿", fontSize = 22.sp); Text("$taps", color = Color(0xFF3B2A00), fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("আজকের জিকির", color = Color(0xFF5C4300), fontSize = 13.sp) }
                Tile(TealBrush, Modifier.weight(1f)) { Text("✅", fontSize = 22.sp); Text("$done", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("সম্পন্ন পর্ব", color = Color(0xFFD9F4FF), fontSize = 13.sp) }
            }
        }
        item {
            GCard {
                Text("দৈনিক জিকির অগ্রগতি", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Chart(run { s.bump; Store.last7(ctx) })
                Text("শেষ ৭ দিন", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }

    // ---------- দোয়া-জিকির লাইব্রেরি ----------
    private fun LazyListScope.libTab(s: UiS) {
        item {
            Text("দোয়া ও জিকির", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("সূত্র ও মান সংকলকের তথ্য অনুযায়ী দেওয়া। ব্যবহারের আগে sunnah.com বা আলেমের কাছে মিলিয়ে নিন। ⚠️ চিহ্নিতগুলোতে মতভেদ বা যাচাই বাকি। নিজের যোগ করাগুলো যাচাই করা নয়।", color = Color.LightGray, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Lib.CATS.forEach { (k, l) ->
                    Text(l, color = if (s.cat == k) Color(0xFF03110A) else Color.White, modifier = Modifier.clip(RoundedCornerShape(50)).background(if (s.cat == k) Green else Green.copy(alpha = .2f)).clickable { s.cat = k }.padding(horizontal = 14.dp, vertical = 8.dp))
                }
            }
        }
        items(s.items.filter { it.cat == s.cat }) { i ->
            GCard {
                val done = run { s.bump; Store.prog(ctx, i.id) }
                ItemBody(i)
                Text(Lib.goalLabel(i), color = Gold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                Text("আজ: $done / ${i.goal}" + if (done >= i.goal) "  ✅" else "", color = Green, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { (done / i.goal.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) }, color = Green, trackColor = Color(0x331FA463), modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val pad = PaddingValues(horizontal = 4.dp)
                    Button(onClick = { Store.addProg(ctx, i.id, 1); s.bump++ }, modifier = Modifier.weight(1f), contentPadding = pad, shape = RoundedCornerShape(12.dp)) { Text("＋১") }
                    OutlinedButton(onClick = { Store.addProg(ctx, i.id, -1); s.bump++ }, modifier = Modifier.weight(1f), contentPadding = pad, shape = RoundedCornerShape(12.dp)) { Text("−১", color = Green) }
                    OutlinedButton(onClick = { Store.setProg(ctx, i.id, 0); s.bump++ }, modifier = Modifier.weight(1f), contentPadding = pad, shape = RoundedCornerShape(12.dp)) { Text("রিসেট", color = Green, fontSize = 12.sp) }
                    OutlinedButton(onClick = { s.edit = i }, modifier = Modifier.weight(1f), contentPadding = pad, shape = RoundedCornerShape(12.dp)) { Text("✏️") }
                }
            }
        }
        item {
            Button(onClick = { s.edit = Item("", s.cat, "", "", "", "", "", "", 0, 10, true, true) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("➕ নতুন দোয়া/জিকির যোগ করুন") }
        }
    }

    // ---------- অ্যাপ লক ----------
    private fun LazyListScope.lockTab(s: UiS) {
        item {
            Text("অ্যাপ লক", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("নির্বাচিত অ্যাপ খোলার আগে জিকির, আর ব্যবহারের সময় পূর্ণ হলে আবার জিকির।", color = Color.LightGray, fontSize = 13.sp)
        }
        item {
            GCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("দোয়া লাইব্রেরি থেকে লক", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Switch(s.libOn, { s.libOn = it; s.saveLibCfg() })
                }
                Text("সারাদিনের তালিকা থেকে র‍্যান্ডম একটা জিকির আসবে; আজকের লক্ষ্য পূর্ণ হয়ে গেলে সেটি আর আসবে না।", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                OutlinedButton(onClick = { s.pick = -2 }, shape = RoundedCornerShape(12.dp)) { Text("📱 অ্যাপ বাছুন (${s.libApps.size}টি)", color = Green) }
                AppRow(s.libApps.toList(), s.names)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(s.libDelay.toString(), { s.libDelay = it.filter(Char::isDigit).take(4).toIntOrNull() ?: 0; s.saveLibCfg() }, label = { Text("কত মিনিট চালানোর পর") }, keyboardOptions = NumKb, modifier = Modifier.weight(1f))
                    OutlinedTextField(s.libCount.toString(), { s.libCount = it.filter(Char::isDigit).take(4).toIntOrNull() ?: 0; s.saveLibCfg() }, label = { Text("প্রতিবার কতবার") }, keyboardOptions = NumKb, modifier = Modifier.weight(1f))
                }
            }
        }
        item { Text("নিজের লেখা জিকির দিয়ে লক (গ্রুপ)", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        itemsIndexed(s.groups) { gi, g ->
            GCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("গ্রুপ ${gi + 1}", color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    if (s.groups.size > 1) Text("🗑️", fontSize = 20.sp, modifier = Modifier.clickable { s.updG(s.groups.filterIndexed { j, _ -> j != gi }) })
                }
                AppRow(g.apps, s.names)
                OutlinedButton(onClick = { s.pick = gi }, shape = RoundedCornerShape(12.dp)) { Text("📱 অ্যাপ বাছুন", color = Green) }
                g.steps.forEachIndexed { si, st ->
                    fun chs(f: (Step) -> Step) = s.chG(gi) { it.copy(steps = it.steps.mapIndexed { k, x -> if (k == si) f(x) else x }) }
                    Column(Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x221FA463)).padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (si == 0) "জিকির ১ (প্রতিবার অ্যাপ খুললে)" else "জিকির ${si + 1}", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (g.steps.size > 1) Text("🗑️", fontSize = 18.sp, modifier = Modifier.clickable { s.chG(gi) { it.copy(steps = it.steps.filterIndexed { k, _ -> k != si }) } })
                        }
                        OutlinedTextField(st.text, { chs { x -> x.copy(text = it) } }, label = { Text("কী পড়বেন") }, modifier = Modifier.fillMaxWidth(), textStyle = LocalTextStyle.current.copy(fontSize = 20.sp, color = Gold))
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(st.count.toString(), { chs { x -> x.copy(count = it.filter(Char::isDigit).take(4).toIntOrNull() ?: 0) } }, label = { Text("কতবার") }, keyboardOptions = NumKb, modifier = Modifier.weight(1f))
                            OutlinedTextField(st.delay.toString(), { chs { x -> x.copy(delay = it.filter(Char::isDigit).take(4).toIntOrNull() ?: 0) } }, label = { Text("কত মিনিট চালানোর পর") }, keyboardOptions = NumKb, modifier = Modifier.weight(1f))
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Button(onClick = { s.chG(gi) { it.copy(steps = it.steps + Step("", 33, 5)) } }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("➕ নতুন জিকির যোগ করুন") }
            }
        }
        item { Button(onClick = { s.updG(s.groups + Store.newGroup()) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF3B2A00))) { Text("➕ আলাদা অ্যাপের জন্য যোগ করুন") } }
    }

    // ---------- সেটিংস ----------
    private fun LazyListScope.setTab(s: UiS, on: Boolean, enable: () -> Unit) {
        item { Text("সেটিংস", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item {
            GCard {
                Text(if (on) "✅ Accessibility চালু" else "⚠️ Accessibility বন্ধ", color = if (on) Green else Gold, fontWeight = FontWeight.Bold)
                Text("এই একটি অনুমতি দিয়েই অ্যাপ অন্য অ্যাপ বা হোম স্ক্রিনের ওপর পূর্ণ পর্দায় জিকির দেখাতে পারে। আলাদা অনুমতি লাগে না।", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                if (!on) Button(onClick = enable, shape = RoundedCornerShape(12.dp)) { Text("চালু করুন") }
            }
        }
        item {
            GCard {
                PrefSwitch("সময়ভিত্তিক পূর্ণ পর্দা জিকির", "pop_on", true)
                Text("নির্ধারিত সময়ের মধ্যে ওই বিভাগের বাকি জিকির আসবে। সময় আপনি বদলাতে পারবেন (২৪ ঘণ্টা, যেমন 05:00)।", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                listOf("M" to "🌅 সকাল", "E" to "🌇 সন্ধ্যা", "N" to "🌙 রাত").forEach { (k, l) ->
                    PrefSwitch(l, "slot_$k", true)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                        TimeField("শুরু", "w_${k}_s", Lib.defS(k), Modifier.weight(1f))
                        TimeField("শেষ", "w_${k}_e", Lib.defE(k), Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            GCard {
                Text("সারাদিনের র‍্যান্ডম রিমাইন্ডার", color = Color.White, fontWeight = FontWeight.Bold)
                Text("সারাদিনের তালিকা থেকে যেকোনো একটা জিকির আসবে। যার আজকের লক্ষ্য পূর্ণ হয়েছে সেটি আর আসবে না।", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                Chips("rand_iv", 15, listOf(0, 5, 10, 15, 30))
                Spacer(Modifier.height(8.dp))
                NumField("প্রতিবার কতবার (একাধিক ভাগে পড়ার জন্য)", "rand_chunk", 10, Modifier.fillMaxWidth())
            }
        }
        item {
            GCard {
                Text("স্কিপ", color = Color.White, fontWeight = FontWeight.Bold)
                Text("স্কিপ করলে কত মিনিট পর আবার আসবে।", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                NumField("স্কিপের পর কত মিনিট", "skip_min", 10, Modifier.fillMaxWidth())
            }
        }
        item {
            GCard {
                PrefSwitch("কল চলাকালীন বিরক্ত করবে না", "call_guard", true)
                Text("এই অ্যাপগুলো চালু থাকলে পূর্ণ পর্দা জিকির আসবে না:", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                OutlinedButton(onClick = { s.pick = -3 }, shape = RoundedCornerShape(12.dp)) { Text("📱 অ্যাপ বাছুন (${s.excl.size}টি)", color = Green) }
                AppRow(s.excl.toList(), s.names)
            }
        }
        item {
            OutlinedButton(onClick = { Store.restoreDefaults(ctx); s.items = Store.lib(ctx) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("ডিফল্ট দোয়াগুলো ফিরিয়ে আনুন (মোছা হলে)", color = Green) }
        }
    }

    // ---------- ছোট উপাদান ----------
    @Composable
    fun PrefSwitch(label: String, key: String, def: Boolean) {
        var v by remember { mutableStateOf(Store.gb(ctx, key, def)) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Switch(v, { v = it; Store.sb(ctx, key, it) })
        }
    }

    @Composable
    fun NumField(label: String, key: String, def: Int, mod: Modifier) {
        var t by remember { mutableStateOf(Store.gi(ctx, key, def).toString()) }
        OutlinedTextField(t, { t = it.filter(Char::isDigit).take(4); t.toIntOrNull()?.let { v -> Store.si(ctx, key, v) } }, label = { Text(label) }, keyboardOptions = NumKb, singleLine = true, modifier = mod)
    }

    @Composable
    fun TimeField(label: String, key: String, def: Int, mod: Modifier) {
        fun parse(x: String): Int? {
            val m = Regex("^(\\d{1,2}):(\\d{2})$").find(x.trim()) ?: return null
            val h = m.groupValues[1].toInt(); val mi = m.groupValues[2].toInt()
            return if (h < 24 && mi < 60) h * 60 + mi else null
        }
        val cur = Store.gi(ctx, key, def)
        var t by remember { mutableStateOf("%02d:%02d".format(cur / 60, cur % 60)) }
        OutlinedTextField(t, { t = it; parse(it)?.let { v -> Store.si(ctx, key, v) } }, label = { Text(label) }, singleLine = true, isError = parse(t) == null, modifier = mod)
    }

    @Composable
    fun Chips(key: String, def: Int, opts: List<Int>) {
        var v by remember { mutableStateOf(Store.gi(ctx, key, def)) }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            opts.forEach { o ->
                Text(if (o == 0) "বন্ধ" else "$o মিনিট", color = if (v == o) Color(0xFF03110A) else Color.White,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (v == o) Green else Green.copy(alpha = .2f))
                        .clickable { v = o; Store.si(ctx, key, o); Store.sl(ctx, "rn", System.currentTimeMillis() + o * 60000L) }.padding(horizontal = 14.dp, vertical = 8.dp))
            }
        }
    }

    @Composable
    fun AppRow(l: List<String>, names: Map<String, String>) {
        if (l.isEmpty()) { Text("কোনো অ্যাপ বাছা হয়নি", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp)); return }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            l.forEach { pkg ->
                val ic = remember(pkg) { icon(pkg) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (ic != null) Image(ic, null, Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)))
                    Text((names[pkg] ?: pkg).take(9), color = Color.LightGray, fontSize = 10.sp)
                }
            }
        }
    }

    @Composable
    fun PickDialog(s: UiS) {
        if (!(s.pick in s.groups.indices || s.pick == -2 || s.pick == -3)) return
        var q by remember { mutableStateOf("") }
        val cur: Set<String> = when { s.pick == -2 -> s.libApps; s.pick == -3 -> s.excl; else -> s.groups[s.pick].apps.toSet() }
        AlertDialog(
            onDismissRequest = { s.pick = -1 }, containerColor = CardC,
            confirmButton = { TextButton(onClick = { s.pick = -1 }) { Text("ঠিক আছে", color = Green) } },
            title = { Text("অ্যাপ বাছুন", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(q, { q = it }, placeholder = { Text("🔍 অ্যাপ খুঁজুন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(s.apps.filter { it.second.contains(q, ignoreCase = true) }) { (pkg, name) ->
                            val sel = pkg in cur
                            val ic = remember(pkg) { icon(pkg) }
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(14.dp))
                                .background(if (sel) Green.copy(alpha = .22f) else Color.Transparent)
                                .clickable { toggle(s, pkg, sel) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (ic != null) Image(ic, null, Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))) else Spacer(Modifier.size(40.dp))
                                Spacer(Modifier.width(12.dp))
                                Text(name, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                Checkbox(sel, null)
                            }
                        }
                    }
                }
            }
        )
    }

    private fun toggle(s: UiS, pkg: String, sel: Boolean) {
        when {
            s.pick == -2 -> { s.libApps = if (sel) s.libApps - pkg else s.libApps + pkg; s.saveLibCfg() }
            s.pick == -3 -> { s.excl = if (sel) s.excl - pkg else s.excl + pkg; Store.ss(ctx, "excl", s.excl) }
            else -> s.updG(s.groups.mapIndexed { j, g -> if (j == s.pick) g.copy(apps = if (sel) g.apps - pkg else g.apps + pkg) else g.copy(apps = g.apps - pkg) })
        }
    }

    @Composable
    fun EditDialog(init: Item, onSave: (Item) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit) {
        var ar by remember { mutableStateOf(init.ar) }
        var tr by remember { mutableStateOf(init.tr) }
        var bn by remember { mutableStateOf(init.bn) }
        var src by remember { mutableStateOf(init.src) }
        var gr by remember { mutableStateOf(init.grade) }
        var goal by remember { mutableStateOf(init.goal.toString()) }
        var cat by remember { mutableStateOf(init.cat) }
        var re by remember { mutableStateOf(init.remind) }
        AlertDialog(
            onDismissRequest = onDismiss, containerColor = CardC,
            title = { Text(if (init.id.isBlank()) "নতুন দোয়া/জিকির" else "সম্পাদনা", color = Color.White) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(ar, { ar = it }, label = { Text("আরবি পাঠ") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(tr, { tr = it }, label = { Text("বাংলা উচ্চারণ") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(bn, { bn = it }, label = { Text("বাংলা অর্থ") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(src, { src = it }, label = { Text("সূত্র (গ্রন্থ ও নম্বর)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(gr, { gr = it }, label = { Text("হাদিসের মান") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(goal, { goal = it.filter(Char::isDigit).take(4) }, label = { Text("দৈনিক লক্ষ্যসংখ্যা") }, keyboardOptions = NumKb, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Lib.CATS.forEach { (k, l) ->
                            Text(l, color = if (cat == k) Color(0xFF03110A) else Color.White, fontSize = 13.sp,
                                modifier = Modifier.clip(RoundedCornerShape(50)).background(if (cat == k) Green else Green.copy(alpha = .2f)).clickable { cat = k }.padding(horizontal = 12.dp, vertical = 6.dp))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("সারাদিনের র‍্যান্ডম রিমাইন্ডারে আসবে", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Switch(re, { re = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (ar.isNotBlank() || tr.isNotBlank()) onSave(init.copy(cat = cat, ar = ar.trim(), tr = tr.trim(), bn = bn.trim(), src = src.trim(), grade = gr.trim(), goal = (goal.toIntOrNull() ?: 1).coerceAtLeast(1), remind = re))
                }) { Text("সংরক্ষণ", color = Green) }
            },
            dismissButton = {
                Row {
                    if (onDelete != null) TextButton(onClick = onDelete) { Text("মুছুন", color = Color(0xFFFF8A80)) }
                    TextButton(onClick = onDismiss) { Text("বাতিল", color = Color.LightGray) }
                }
            }
        )
    }
}

@Composable
fun Chart(d: List<Int>) {
    val mx = (d.maxOrNull() ?: 1).coerceAtLeast(1)
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val pts = d.mapIndexed { i, v -> Offset(size.width * i / 6f, size.height * (1 - v / mx.toFloat() * .85f) - 6f) }
        val fill = Path().apply { moveTo(0f, size.height); pts.forEach { lineTo(it.x, it.y) }; lineTo(size.width, size.height); close() }
        drawPath(fill, Brush.verticalGradient(listOf(Green.copy(alpha = .35f), Color.Transparent)))
        val line = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
        drawPath(line, Green, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f, cap = StrokeCap.Round))
        pts.forEach { drawCircle(Gold, 7f, it) }
    }
}
