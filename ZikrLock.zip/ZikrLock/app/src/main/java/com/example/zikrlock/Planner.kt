package com.example.zikrlock
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

data class Dua(val id: String, val text: String, val target: Int, val note: String)
data class Pick(val dua: Dua, val tip: String)

val CATALOG = listOf(
    Dua("istighfar", "আস্তাগফিরুল্লাহ", 70, "রাসূলুল্লাহ (সা.) দিনে ৭০ বারের বেশি ইস্তিগফার করতেন (সহীহ বুখারী)"),
    Dua("tasbih_hamd", "সুবহানাল্লাহি ওয়া বিহামদিহি", 100, "দিনে ১০০ বার পড়লে গুনাহ মাফ হয় (সহীহ বুখারী ও মুসলিম)"),
    Dua("tawhid", "লা ইলাহা ইল্লাল্লাহু ওয়াহদাহু লা শারীকা লাহু, লাহুল মুলকু ওয়া লাহুল হামদু ওয়া হুয়া আলা কুল্লি শাইয়িন কাদীর", 100, "দিনে ১০০ বার পড়ার ফযীলত (সহীহ বুখারী ও মুসলিম)"),
    Dua("subhanallah", "সুবহানাল্লাহ", 33, "নামাযের পর ৩৩ বার (সহীহ মুসলিম)"),
    Dua("alhamdulillah", "আলহামদুলিল্লাহ", 33, "নামাযের পর ৩৩ বার (সহীহ মুসলিম)"),
    Dua("allahu_akbar", "আল্লাহু আকবার", 34, "নামাযের পর ৩৪ বার (সহীহ মুসলিম)"),
    Dua("durood", "আল্লাহুম্মা সাল্লি আলা মুহাম্মাদ", 10, "একবার দরুদে আল্লাহ ১০ বার রহমত দেন (সহীহ মুসলিম)"),
    Dua("hawqala", "লা হাওলা ওয়ালা কুওয়াতা ইল্লা বিল্লাহ", 20, "জান্নাতের ধনভাণ্ডারগুলোর একটি (সহীহ বুখারী ও মুসলিম)")
)

object Net {
    fun online(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
    }
}

object Planner {
    fun local(c: Context): Pick {
        val last = Store.aiLast(c)
        val sorted = CATALOG.sortedBy { Store.aiDone(c, it.id).toFloat() / it.target }
        return Pick(sorted.firstOrNull { it.id != last } ?: sorted.first(), "")
    }

    fun online(c: Context): Pick {
        for (m in listOf(BuildConfig.AI_MODEL, "deepseek-v4.1-flash", "deepseek-v4-flash-free").distinct()) {
            try { ask(c, m)?.let { return it } } catch (e: Exception) { }
        }
        return local(c)
    }

    private fun ask(c: Context, model: String): Pick? {
        if (BuildConfig.AI_KEY.isBlank()) return null
        val cal = Calendar.getInstance()
        val now = "%02d:%02d".format(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
        val prog = CATALOG.joinToString("\n") { "${it.id}: আজ ${Store.aiDone(c, it.id)}/${it.target} — ${it.text}" }
        val sys = "তুমি একটি জিকির সহায়ক। শুধু নিচের তালিকা থেকে একটি id বাছবে, নতুন দোয়া বা হাদিস বানাবে না। " +
            "দিনের লক্ষ্যগুলো সারাদিনে ছড়িয়ে পূরণ হয় এমনভাবে বাছো। সময়ের সাথে মানানসই বাছো (সকাল, দুপুর, সন্ধ্যা, রাত)। " +
            "একই জিকির পরপর দিও না। যার লক্ষ্য পূর্ণ হয়েছে তা এড়াও, যদি অন্যগুলো বাকি থাকে। " +
            "উত্তর শুধু JSON: {\"id\":\"...\",\"tip\":\"১২ শব্দের মধ্যে বাংলায় ছোট উৎসাহ বাক্য, হাদিসের উদ্ধৃতি ছাড়া\"}"
        val user = "এখন সময়: $now\nশেষবার দেওয়া: ${Store.aiLast(c)}\nআজকের অগ্রগতি:\n$prog"
        val body = JSONObject().put("model", model).put("temperature", 0.7).put("max_tokens", 400)
            .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", sys)).put(JSONObject().put("role", "user").put("content", user)))
        val con = URL("https://opencode.ai/zen/v1/chat/completions").openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.connectTimeout = 4000; con.readTimeout = 8000; con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("Authorization", "Bearer " + BuildConfig.AI_KEY)
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        if (con.responseCode !in 200..299) return null
        val txt = con.inputStream.bufferedReader().readText()
        val content = JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        val m = Regex("\\{.*\\}", RegexOption.DOT_MATCHES_ALL).find(content)?.value ?: return null
        val o = JSONObject(m)
        val d = CATALOG.firstOrNull { it.id == o.optString("id") } ?: return null
        return Pick(d, o.optString("tip").take(120))
    }
}
