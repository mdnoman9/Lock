package com.example.zikrlock
import android.content.Context
import java.time.LocalDate

object Store {
    private fun p(c: Context) = c.getSharedPreferences("s", 0)
    private fun today() = LocalDate.now().toString()
    fun dhikr(c: Context) = p(c).getString("dhikr", "আলহামদুলিল্লাহ")!!
    fun target(c: Context) = p(c).getInt("target", 33)
    fun minutes(c: Context) = p(c).getInt("minutes", 10)
    fun locked(c: Context): Set<String> = p(c).getStringSet("locked", emptySet())!!
    fun unlockUntil(c: Context) = p(c).getLong("until", 0L)
    fun save(c: Context, dhikr: String, target: Int, minutes: Int, locked: Set<String>) =
        p(c).edit().putString("dhikr", dhikr).putInt("target", target).putInt("minutes", minutes)
            .putStringSet("locked", locked.toSet()).apply()
    fun complete(c: Context) {
        val e = p(c).edit()
        e.putInt("d_" + today(), dhikrToday(c) + target(c))
        e.putInt("m_" + today(), minutesToday(c) + minutes(c))
        e.putLong("until", System.currentTimeMillis() + minutes(c) * 60_000L).apply()
    }
    fun dhikrToday(c: Context) = p(c).getInt("d_" + today(), 0)
    fun minutesToday(c: Context) = p(c).getInt("m_" + today(), 0)
    fun last7(c: Context): List<Int> = (6 downTo 0).map { p(c).getInt("d_" + LocalDate.now().minusDays(it.toLong()), 0) }
}
