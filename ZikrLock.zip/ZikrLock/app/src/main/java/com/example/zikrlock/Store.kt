package com.example.zikrlock
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class Step(val text: String, val count: Int, val delay: Int)
data class Group(val id: String, val apps: List<String>, val steps: List<Step>)
data class Item(
    val id: String, val cat: String, val ar: String, val tr: String, val bn: String, val src: String,
    val grade: String, val virtue: String, val sunnah: Int, val goal: Int, val custom: Boolean = false, val remind: Boolean = true
)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("s2", 0)
    private fun today() = LocalDate.now().toString()
    fun gi(c: Context, k: String, d: Int) = p(c).getInt(k, d)
    fun si(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
    fun gb(c: Context, k: String, d: Boolean) = p(c).getBoolean(k, d)
    fun sb(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
    fun gl(c: Context, k: String) = p(c).getLong(k, 0L)
    fun sl(c: Context, k: String, v: Long) = p(c).edit().putLong(k, v).apply()
    fun gs(c: Context, k: String): Set<String> = p(c).getStringSet(k, emptySet())!!
    fun ss(c: Context, k: String, v: Set<String>) = p(c).edit().putStringSet(k, v.toSet()).apply()

    // ---- app-lock groups (manual) ----
    fun newGroup() = Group(java.util.UUID.randomUUID().toString().take(8), emptyList(), listOf(Step("", 33, 5)))
    fun groups(c: Context): List<Group> {
        val s = p(c).getString("groups", null)
            ?: return listOf(Group("g0", emptyList(), listOf(Step("আলহামদুলিল্লাহ", 33, 5), Step("আস্তাগফিরুল্লাহ", 20, 5))))
        val a = JSONArray(s)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val ap = o.getJSONArray("a"); val st = o.getJSONArray("s")
            Group(o.getString("id"), (0 until ap.length()).map { ap.getString(it) },
                (0 until st.length()).map { st.getJSONObject(it).let { x -> Step(x.getString("t"), x.getInt("c"), x.getInt("d")) } }
                    .ifEmpty { listOf(Step("", 33, 5)) })
        }
    }
    fun saveGroups(c: Context, l: List<Group>) {
        val a = JSONArray()
        l.forEach { g ->
            val sa = JSONArray(); g.steps.forEach { sa.put(JSONObject().put("t", it.text).put("c", it.count).put("d", it.delay)) }
            a.put(JSONObject().put("id", g.id).put("a", JSONArray(g.apps)).put("s", sa))
        }
        p(c).edit().putString("groups", a.toString()).apply()
    }
    fun groupFor(c: Context, pkg: String) = groups(c).firstOrNull { pkg in it.apps }
    fun idx(c: Context, g: Group) = p(c).getInt("i_" + g.id, 1 % g.steps.size).coerceIn(0, g.steps.size - 1)
    fun used(c: Context, id: String) = p(c).getInt("u_$id", 0)
    fun setUsed(c: Context, id: String, v: Int) = p(c).edit().putInt("u_$id", v).apply()
    fun advance(c: Context, g: Group) = p(c).edit().putInt("i_" + g.id, (idx(c, g) + 1) % g.steps.size).putInt("u_" + g.id, 0).apply()
    fun gate(c: Context) = p(c).getString("gate", "")!!
    fun setGate(c: Context, v: String) = p(c).edit().putString("gate", v).apply()
    fun setPending(c: Context, pkg: String, kind: String, gid: String) = p(c).edit().putString("pp", pkg).putString("pk", kind).putString("pg", gid).apply()
    fun pendPkg(c: Context) = p(c).getString("pp", "")!!
    fun pendKind(c: Context) = p(c).getString("pk", "")!!
    fun pendGid(c: Context) = p(c).getString("pg", "")!!

    // ---- stats ----
    fun addStats(c: Context, n: Int) = p(c).edit().putInt("d_" + today(), dhikrToday(c) + n).putInt("m_" + today(), doneToday(c) + 1).apply()
    fun addDone(c: Context) = p(c).edit().putInt("m_" + today(), doneToday(c) + 1).apply()
    fun dhikrToday(c: Context) = p(c).getInt("d_" + today(), 0)
    fun doneToday(c: Context) = p(c).getInt("m_" + today(), 0)
    fun last7(c: Context): List<Int> = (6 downTo 0).map { p(c).getInt("d_" + LocalDate.now().minusDays(it.toLong()), 0) }

    // ---- library ----
    fun lib(c: Context): List<Item> {
        val s = p(c).getString("lib", null) ?: return Defaults.all()
        val a = JSONArray(s)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Item(o.getString("id"), o.getString("c"), o.getString("ar"), o.getString("tr"), o.getString("bn"), o.getString("src"),
                o.getString("gr"), o.getString("vi"), o.getInt("su"), o.getInt("go"), o.optBoolean("cu"), o.optBoolean("re", true))
        }
    }
    fun saveLib(c: Context, l: List<Item>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("c", it.cat).put("ar", it.ar).put("tr", it.tr).put("bn", it.bn).put("src", it.src)
                .put("gr", it.grade).put("vi", it.virtue).put("su", it.sunnah).put("go", it.goal).put("cu", it.custom).put("re", it.remind))
        }
        p(c).edit().putString("lib", a.toString()).apply()
    }
    fun restoreDefaults(c: Context) {
        val cur = lib(c); val ids = cur.map { it.id }.toSet()
        saveLib(c, cur + Defaults.all().filter { it.id !in ids })
    }
    fun prog(c: Context, id: String) = p(c).getInt("lp_" + today() + "_" + id, 0)
    fun setProg(c: Context, id: String, v: Int) = p(c).edit().putInt("lp_" + today() + "_" + id, v.coerceAtLeast(0)).apply()
    fun addProg(c: Context, id: String, n: Int) {
        setProg(c, id, prog(c, id) + n)
        if (n > 0) p(c).edit().putInt("d_" + today(), dhikrToday(c) + n).apply()
    }
}
