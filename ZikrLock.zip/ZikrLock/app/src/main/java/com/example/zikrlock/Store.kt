package com.example.zikrlock
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class Step(val text: String, val count: Int, val delay: Int)
data class Group(val id: String, val apps: List<String>, val steps: List<Step>)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("s2", 0)
    private fun today() = LocalDate.now().toString()
    fun newGroup() = Group(java.util.UUID.randomUUID().toString().take(8), emptyList(), listOf(Step("", 33, 5)))
    fun groups(c: Context): List<Group> {
        val s = p(c).getString("groups", null)
            ?: return listOf(Group("g0", emptyList(), listOf(Step("আলহামদুলিল্লাহ", 33, 5), Step("আস্তাগফিরুল্লাহ", 20, 5))))
        val a = JSONArray(s)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val ap = o.getJSONArray("a"); val st = o.getJSONArray("s")
            Group(o.getString("id"), (0 until ap.length()).map { ap.getString(it) },
                (0 until st.length()).map { st.getJSONObject(it).let { x -> Step(x.getString("t"), x.getInt("c"), x.getInt("d")) } }
                    .ifEmpty { listOf(Step("", 33, 5)) })
        }
    }
    fun saveGroups(c: Context, l: List<Group>) {
        val a = JSONArray()
        l.forEach { g ->
            val sa = JSONArray(); g.steps.forEach { sa.put(JSONObject().put("t", it.text).put("c", it.count).put("d", it.delay)) }
            a.put(JSONObject().put("id", g.id).put("a", JSONArray(g.apps)).put("s", sa))
        }
        p(c).edit().putString("groups", a.toString()).apply()
    }
    fun groupFor(c: Context, pkg: String) = groups(c).firstOrNull { pkg in it.apps }
    fun idx(c: Context, g: Group) = p(c).getInt("i_" + g.id, 1 % g.steps.size).coerceIn(0, g.steps.size - 1)
    fun used(c: Context, id: String) = p(c).getInt("u_$id", 0)
    fun setUsed(c: Context, id: String, v: Int) = p(c).edit().putInt("u_$id", v).apply()
    fun advance(c: Context, g: Group) = p(c).edit().putInt("i_" + g.id, (idx(c, g) + 1) % g.steps.size).putInt("u_" + g.id, 0).apply()
    fun gate(c: Context) = p(c).getString("gate", "")!!
    fun setGate(c: Context, v: String) = p(c).edit().putString("gate", v).apply()
    fun setPending(c: Context, pkg: String, kind: String, gid: String) = p(c).edit().putString("pp", pkg).putString("pk", kind).putString("pg", gid).apply()
    fun pendPkg(c: Context) = p(c).getString("pp", "")!!
    fun pendKind(c: Context) = p(c).getString("pk", "")!!
    fun pendGid(c: Context) = p(c).getString("pg", "")!!
    fun addStats(c: Context, n: Int) = p(c).edit().putInt("d_" + today(), dhikrToday(c) + n).putInt("m_" + today(), doneToday(c) + 1).apply()
    fun dhikrToday(c: Context) = p(c).getInt("d_" + today(), 0)
    fun doneToday(c: Context) = p(c).getInt("m_" + today(), 0)
    fun last7(c: Context): List<Int> = (6 downTo 0).map { p(c).getInt("d_" + LocalDate.now().minusDays(it.toLong()), 0) }
    fun aiOn(c: Context) = p(c).getBoolean("ai_on", true)
    fun aiApps(c: Context): Set<String> = p(c).getStringSet("ai_apps", emptySet())!!
    fun aiDelay(c: Context) = p(c).getInt("ai_delay", 10)
    fun aiCount(c: Context) = p(c).getInt("ai_count", 10)
    fun saveAi(c: Context, on: Boolean, apps: Set<String>, delay: Int, count: Int) =
        p(c).edit().putBoolean("ai_on", on).putStringSet("ai_apps", apps.toSet()).putInt("ai_delay", delay).putInt("ai_count", count).apply()
    fun aiDone(c: Context, id: String) = p(c).getInt("a_" + today() + id, 0)
    fun aiLast(c: Context) = p(c).getString("ai_last", "")!!
    fun addAi(c: Context, id: String, n: Int) = p(c).edit().putInt("a_" + today() + id, aiDone(c, id) + n).putString("ai_last", id).apply()
}
