package com.example.zikrlock
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val BgBrush = Brush.verticalGradient(listOf(Color(0xFF03110A), Color(0xFF0B3D2A)))
val CardC = Color(0xFF0F2A1E)
val Green = Color(0xFF2ECC71)
val Gold = Color(0xFFFFD66B)
val HeroBrush = Brush.linearGradient(listOf(Color(0xFF1FA463), Color(0xFF0E7C86)))
val GoldBrush = Brush.linearGradient(listOf(Color(0xFFFFD66B), Color(0xFFF59E0B)))
val TealBrush = Brush.linearGradient(listOf(Color(0xFF14B8A6), Color(0xFF0369A1)))
val NumKb = KeyboardOptions(keyboardType = KeyboardType.Number)

@Composable
fun GCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) = Column(
    modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CardC)
        .border(1.dp, Green.copy(alpha = .25f), RoundedCornerShape(22.dp)).padding(16.dp),
    content = content
)

@Composable
fun Tile(brush: Brush, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) = Column(
    modifier.clip(RoundedCornerShape(22.dp)).background(brush).padding(16.dp), content = content
)

@Composable
fun ItemBody(i: Item) {
    if (i.ar.isNotBlank()) Text(i.ar, color = Gold, fontSize = 24.sp, lineHeight = 40.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    if (i.tr.isNotBlank()) Text(i.tr, color = Color.White, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
    if (i.bn.isNotBlank()) Text("অর্থ: " + i.bn, color = Color(0xFFCFE8DA), fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
    if (i.src.isNotBlank()) Text("📖 সূত্র: " + i.src, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
    val g = if (i.custom && i.grade.isBlank()) "নিজের যোগ করা — যাচাই করা নয়" else i.grade
    if (g.isNotBlank()) Text("🔎 মান: $g", color = Color(0xFFFFE9A8), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
}
